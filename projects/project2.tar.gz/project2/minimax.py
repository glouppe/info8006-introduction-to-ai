from pacman_module.game import Agent
from pacman_module.pacman import Directions


def key(state):
    """
    Returns a key that uniquely identifies a game state which includes
    matrix of food dots, the position and orientation of the ghost and
    the position of Pacman.

    Arguments:
    ----------
    - state: the current game state. See FAQ and class
               pacman.GameState.

    Return:
    -------
    - A hashable key object that uniquely identifies a game state.
    """
    return (state.getPacmanPosition(),
            state.getGhostPosition(1), state.getGhostDirection(1), tuple(state.getFood().asList()))

class PacmanAgent(Agent):
    def __init__(self, args):
        """
        Arguments:
        ----------
        - `args`: Namespace of arguments from command-line prompt.
        """
        self.args = args
        # self.closed = set()  # set to avoid repeated states
        self.path = []

    def get_action(self, state):
        """
        Given a pacman game state, returns a legal move.

        Arguments:
        ----------
        - `state`: the current game state. See FAQ and class
                   `pacman.GameState`.

        Return:
        -------
        - A legal move as defined in `game.Directions`.
        """
        pacman_actions = state.getLegalPacmanActions()
        max_value = float('-inf')
        max_action = None

        path = set()  # to avoid repeated states in the same path
        current_key = key(state)
        path.add(current_key)

        for action in pacman_actions:
            next_state = state.generatePacmanSuccessor(action)
            action_value = self.minValue(next_state, path)
            if(action_value > max_value):
                max_value = action_value
                max_action = action

        return max_action

    def maxValue(self, state, path):
        """
        Given a pacman game state,
        returns the value that maximizes the winning chance of the ghost
        according to Minimax algorithm.

        Arguments:
        ----------
        - state: the current game state. See FAQ and class
                   pacman.GameState.

        Return:
        -------
        - The value that maximizes the winning chance of the pacman
          according to Minimax algorithm.
          """

        current_key = key(state)


        if(state.isWin() or state.isLose()):
            return state.getScore()

        if(current_key in path):
            return float('-inf')

        values = []
        for next_state, action in state.generatePacmanSuccessors():
            next_key = key(next_state)
            values.append(self.minValue(next_state, path.union(set([current_key]))))

        return max(values)

    def minValue(self, state, path):
        """
        Given a pacman game state,
        returns the value that maximizes the winning chance of the ghost
        according to Minimax algorithm.

        Arguments:
        ----------
        - state: the current game state. See FAQ and class
                   pacman.GameState.

        Return:
        -------
        - The value that maximizes the winning chance of the ghost
          according to Minimax algorithm.
          """
        current_key = key(state)
        # if(state in path)
        if(state.isWin() or state.isLose()):
            return state.getScore()

        if(current_key in path):
            return float('-inf')

        values = []

        for next_state, action in state.generateGhostSuccessors(1): 
            next_key = key(next_state)
            values.append(self.maxValue(next_state, path.union(set([current_key]))))

        return min(values)
