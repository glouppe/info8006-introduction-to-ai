import torch
import torch.nn as nn


class PacmanNetwork(nn.Module):
    """
    Your neural network architecture.
    """
    def __init__(self):
        super().__init__()
        # Your code here

    def forward(self, x):
        # Your code here
        return # ...
